prices = {
    'GOOG' : 513.25,
    'CAT' : 87.22,
    'IBM' : 93.37,
    'MSFT' : 44.12
}
