# mortgage.py
#
# Exercise 1.7
principal = 500000
rate = 0.05
payment = 2684.11
Tpaid = 0.0
month = 0
extrapayment_start = int(input("Enter Start Month"))
extrapayment_end = int(input("Enter End Month"))
extrapayment = int(input("ExtraPaymentValue"))

while principal > 0:
    if principal < payment:
        Tpaid = Tpaid + principal
        principal = 0
        month = month+1
        print(f'{Tpaid} $ has been paid so far in {month} months and the amount left to be paid is {principal} $')
        continue
    if month <= extrapayment_end and month >= extrapayment_start:
        principal = principal*(1+rate/12) - (payment+extrapayment)
        Tpaid = Tpaid + payment + extrapayment
        month = month+1
        print(f'{Tpaid} $ has been paid so far in {month} months and the amount left to be paid is {principal} $')
        continue
    principal = principal*(1+rate/12) - payment
    Tpaid = Tpaid + payment
    month = month + 1
    print(f'{Tpaid} $ has been paid so far in {month} months and the amount left to be paid is {principal} $')
print("Total_Paid =", Tpaid)
print("Months =", month)
