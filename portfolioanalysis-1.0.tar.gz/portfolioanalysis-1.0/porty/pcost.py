# pcost.py
#
# Exercise 1.27
