This is an application package which basically successfully makes a complete analysis application for any stock portfolio including realtime monitoring. 
Kshitij Gupta WWWW
