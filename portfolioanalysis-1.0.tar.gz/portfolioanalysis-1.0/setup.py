import setuptools
setuptools.setup(
    name = "portfolioAnalysis",
    version = "1.0",
    author = "Kshitij",
    author_email="kshitij748@gmail.com",
    description="PortfolioAnalysisApp",
    packages = setuptools.find_packages(),
)